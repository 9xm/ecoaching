-- Adminer 4.8.1 MySQL 8.0.33-0ubuntu0.22.10.2 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE TABLE `batches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `batch_start` date NOT NULL,
  `batch_end` date NOT NULL,
  `fee` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_id` bigint NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `batches` (`id`, `title`, `description`, `batch_start`, `batch_end`, `fee`, `course_id`, `status`, `created_at`, `updated_at`) VALUES
(1,	'2500',	'<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sollicitudin semper arcu ac semper. Duis vestibulum luctus ligula vitae sollicitudin. In hac habitasse platea dictumst. Nam porttitor nisl vitae tellus accumsan dignissim. Nullam pharetra vel dolor in vehicula. Vivamus risus tortor, feugiat at tellus aliquam, rhoncus hendrerit sapien. Morbi cursus vulputate erat, vel convallis ipsum semper vel. Ut non sem vulputate, molestie odio sit amet, tincidunt nunc. Integer finibus risus vel sapien lobortis, id molestie felis tempus. Praesent placerat tellus eu erat congue maximus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed gravida magna a nulla porta accumsan. Proin pellentesque ex nec est commodo mollis. Donec non enim eu augue cursus feugiat lacinia non erat.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Donec aliquet iaculis quam tempor sodales. Nullam maximus, tortor eu pretium gravida, enim elit venenatis ante, ac sagittis felis tellus consectetur lacus. Donec a purus diam. Duis metus erat, hendrerit ac ultricies eget, volutpat sed dui. Proin vel dapibus nibh. Vivamus sed nunc iaculis, ultrices risus eget, efficitur nunc. Nunc et justo eget metus eleifend congue. Maecenas nisi tellus, sollicitudin vitae tortor quis, convallis commodo massa. In hac habitasse platea dictumst.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Vestibulum ac sapien rutrum, viverra dolor ullamcorper, mollis leo. Mauris sed orci mi. Sed nunc felis, convallis non felis quis, pharetra elementum risus. Fusce ac orci et diam lobortis dapibus. Mauris tincidunt pharetra felis a ullamcorper. Suspendisse id vestibulum ligula. Phasellus interdum fermentum ultrices. Suspendisse sit amet metus elit. Ut non finibus elit. Aliquam convallis consequat ex a feugiat. Cras lorem elit, eleifend id tortor sit amet, mollis porttitor odio.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Mauris placerat mollis elit, in ultricies nunc faucibus eu. Ut volutpat, orci nec tincidunt porttitor, lorem metus finibus sem, quis faucibus mi turpis sed est. In felis odio, lobortis quis vulputate a, maximus at tellus. Vestibulum in augue fringilla, molestie purus efficitur, gravida nibh. Duis vitae massa at velit euismod scelerisque quis eget nibh. Morbi ac porta ligula, vel ullamcorper arcu. Aliquam erat volutpat. Proin ut neque ex. Integer feugiat viverra sapien, id semper tortor venenatis eu. Sed eu quam nec tellus bibendum consectetur. Donec euismod pellentesque ante iaculis porttitor. Suspendisse maximus porttitor feugiat. Suspendisse potenti.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec pulvinar faucibus iaculis. Fusce ante ipsum, porta eget mattis non, suscipit eget metus. Nam fermentum, nunc a lacinia pellentesque, diam arcu fermentum massa, ac volutpat ante ex id libero. Nunc ac nibh facilisis, laoreet purus ut, volutpat odio. Vivamus eu purus congue, hendrerit ex at, luctus eros. Cras faucibus nisl eget dignissim interdum. Aliquam finibus tristique ultrices. Curabitur pellentesque ultrices est in auctor. Aenean eu enim a purus consequat commodo. Maecenas feugiat consequat egestas. Proin sodales odio nec maximus aliquam. Vivamus eu eros at nisl feugiat viverra. Etiam elementum at dui a vestibulum.</p>',	'2023-08-10',	'2024-02-23',	'2500',	1,	'draft',	'2023-08-10 03:10:07',	'2023-08-10 03:16:45');

CREATE TABLE `courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courses_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `courses` (`id`, `title`, `slug`, `image`, `content`, `status`, `created_at`, `updated_at`) VALUES
(1,	'Computer Application',	'computer-application',	'post/2023/08/male-placeholder-image.jpeg',	'<div style=\"color: rgb(0, 0, 0); font-family: &quot;Droid Sans Mono&quot;, &quot;monospace&quot;, monospace; font-size: 14px; line-height: 19px; white-space: pre;\"><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; font-family: &quot;Open Sans&quot;, Arial, sans-serif; white-space: normal;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sollicitudin semper arcu ac semper. Duis vestibulum luctus ligula vitae sollicitudin. In hac habitasse platea dictumst. Nam porttitor nisl vitae tellus accumsan dignissim. Nullam pharetra vel dolor in vehicula. Vivamus risus tortor, feugiat at tellus aliquam, rhoncus hendrerit sapien. Morbi cursus vulputate erat, vel convallis ipsum semper vel. Ut non sem vulputate, molestie odio sit amet, tincidunt nunc. Integer finibus risus vel sapien lobortis, id molestie felis tempus. Praesent placerat tellus eu erat congue maximus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed gravida magna a nulla porta accumsan. Proin pellentesque ex nec est commodo mollis. Donec non enim eu augue cursus feugiat lacinia non erat.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; font-family: &quot;Open Sans&quot;, Arial, sans-serif; white-space: normal;\">Donec aliquet iaculis quam tempor sodales. Nullam maximus, tortor eu pretium gravida, enim elit venenatis ante, ac sagittis felis tellus consectetur lacus. Donec a purus diam. Duis metus erat, hendrerit ac ultricies eget, volutpat sed dui. Proin vel dapibus nibh. Vivamus sed nunc iaculis, ultrices risus eget, efficitur nunc. Nunc et justo eget metus eleifend congue. Maecenas nisi tellus, sollicitudin vitae tortor quis, convallis commodo massa. In hac habitasse platea dictumst.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; font-family: &quot;Open Sans&quot;, Arial, sans-serif; white-space: normal;\">Vestibulum ac sapien rutrum, viverra dolor ullamcorper, mollis leo. Mauris sed orci mi. Sed nunc felis, convallis non felis quis, pharetra elementum risus. Fusce ac orci et diam lobortis dapibus. Mauris tincidunt pharetra felis a ullamcorper. Suspendisse id vestibulum ligula. Phasellus interdum fermentum ultrices. Suspendisse sit amet metus elit. Ut non finibus elit. Aliquam convallis consequat ex a feugiat. Cras lorem elit, eleifend id tortor sit amet, mollis porttitor odio.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; font-family: &quot;Open Sans&quot;, Arial, sans-serif; white-space: normal;\">Mauris placerat mollis elit, in ultricies nunc faucibus eu. Ut volutpat, orci nec tincidunt porttitor, lorem metus finibus sem, quis faucibus mi turpis sed est. In felis odio, lobortis quis vulputate a, maximus at tellus. Vestibulum in augue fringilla, molestie purus efficitur, gravida nibh. Duis vitae massa at velit euismod scelerisque quis eget nibh. Morbi ac porta ligula, vel ullamcorper arcu. Aliquam erat volutpat. Proin ut neque ex. Integer feugiat viverra sapien, id semper tortor venenatis eu. Sed eu quam nec tellus bibendum consectetur. Donec euismod pellentesque ante iaculis porttitor. Suspendisse maximus porttitor feugiat. Suspendisse potenti.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; font-family: &quot;Open Sans&quot;, Arial, sans-serif; white-space: normal;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec pulvinar faucibus iaculis. Fusce ante ipsum, porta eget mattis non, suscipit eget metus. Nam fermentum, nunc a lacinia pellentesque, diam arcu fermentum massa, ac volutpat ante ex id libero. Nunc ac nibh facilisis, laoreet purus ut, volutpat odio. Vivamus eu purus congue, hendrerit ex at, luctus eros. Cras faucibus nisl eget dignissim interdum. Aliquam finibus tristique ultrices. Curabitur pellentesque ultrices est in auctor. Aenean eu enim a purus consequat commodo. Maecenas feugiat consequat egestas. Proin sodales odio nec maximus aliquam. Vivamus eu eros at nisl feugiat viverra. Etiam elementum at dui a vestibulum.</p></div>',	'draft',	'2023-08-08 02:02:21',	'2023-08-10 03:17:02');

CREATE TABLE `join_courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `batch_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `transaction_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_date` date NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `join_courses` (`id`, `course_id`, `batch_id`, `user_id`, `transaction_number`, `transaction_date`, `status`, `created_at`, `updated_at`) VALUES
(6,	1,	1,	2,	'rwert2424',	'2023-08-05',	'certificate',	'2023-08-11 01:44:31',	'2023-08-19 20:40:36'),
(7,	1,	1,	3,	'wrwrwer232353',	'2023-08-25',	'certificate',	'2023-08-26 21:20:29',	'2023-08-26 21:35:05');

CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2022_10_12_000000_create_users_table',	1),
(2,	'2023_08_08_071040_create_course_table',	2),
(4,	'2023_08_08_121612_create_batches_table',	3),
(6,	'2023_08_11_064310_create_join_course_table',	4),
(7,	'2023_08_11_064310_create_join_courses_table',	5);

CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `summary`, `image`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(2,	'Admin',	'admin@news7.com',	NULL,	'$2y$10$yjgMRnqv7x1U9eAxKgT6Ou6VguNhvv3nizL.xagZ3C4WswwxQsWkC',	'<p>This is Admin User</p>',	'user/2023/08/male-placeholder-image.jpeg',	'admin',	NULL,	'2023-08-07 08:02:32',	'2023-08-07 22:14:51'),
(3,	'Test1',	'jojo@yopmail.com',	NULL,	'$2y$10$W73IWqMvBRXWwT4xQ.PGXOIa0iZt9lhayjBGzivKT5g9aOz7LjJOC',	NULL,	NULL,	'subscriber',	NULL,	'2023-08-07 22:17:43',	'2023-08-07 22:17:43');

-- 2023-08-27 11:02:09
